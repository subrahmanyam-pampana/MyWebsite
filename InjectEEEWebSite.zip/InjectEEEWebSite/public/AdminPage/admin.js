//adding new question
//if request.auth != null
var storageRef = storage.ref();
var file;
var question = {
    qid: ""
}
var form = document.getElementById("addNewQuestionForm");
form.addEventListener('submit', (event) => {
    event.preventDefault();
    // if (form.question.value == '') {
    //     alert("Please enter Question");
    //     return;
    // } else {
        var list = $("#add_opt_list li");
        console.log(list);
        var options = [];
        for (let i = 0; i < list.length; i++) {
            options.push($(list).eq(i).find("input").val());
        }
        console.log(options);

        db.collection('questions').add({
            question: form.question.value,
            options: options,
            answer: form.answer.value,
            solution: form.solution.value,
            subject: form.subject.value,
            type: form.type.value,
            year: form.year.value
        }).then((docRef) => {
            alert("question added successfully with doc id: " + docRef.id);
            question.qid = docRef.id;
        }).catch((error) => {
            alert("Error occured while Addeding new document. Error: " + error);
        });

});

$("#add_opt_btn").click(() => {
    let ul = document.createElement('li');
    let input = document.createElement('input');
    $(ul).append(input);
    $("#add_opt_list").append(ul);

});

function uploadFile(imageType) {
    var elementRef = $(this);
    console.log(question.qid);
    if (question.qid != "") {
        /*-------------------creating  input element with type file-----------------------------------------------------------------------*/
        let input = document.createElement('input');
        input.type = 'file';
        input.click();
        input.onchange = (event) => {
            /*----------------------------getting the image-----------------------------------------------------------------------*/
            file = event.target.files[0];
            var imagesRef = storageRef.child('images');
            var imageName;
            if (imageType == 'Q') {
                imageName = question.qid + "_Qimage";

            } else if (imageType == 'S') {
                imageName = question.qid + "_Simage";
            }
            /*-----------------------------Uploading image----------------------------------------------------------------------*/
            var imageRef = imagesRef.child(imageName);
            var uploadTask = imageRef.put(file);
            /*------------------------------Showing upload status---------------------------------------------------------------------*/

            uploadTask.on('state_changed', (snapshot) => {
                    var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                    $("#uploadStatus").text("uploaded " + progress + "%");

                },
                /*------------------------------on Error ---------------------------------------------------------------------*/
                (error) => {
                    alert("Error:" + error);
                },
                /*----------------------------on completion of upload-------------------------------------------------------------------*/
                () => {
                    var imageUrl;
                    uploadTask.snapshot.ref.getDownloadURL().then((url) => {
                        imageUrl = url;
                        console.log(imageUrl);
                        if (imageType == 'Q') {
                            db.collection('questions').doc(question.qid).update({
                                Qimage: imageUrl
                            }).then(()=>{
                                alert("image upload successfully with path: " + imageUrl);
                            });

                        } else if (imageType == 'S') {
                            db.collection('questions').doc(question.qid).update({
                                Simage: imageUrl
                            }).then(()=>{
                                alert("image upload successfully with path: " + imageUrl);
                            });
                        }

                    });
                }
            );
        }
            /*----------------------------if quetion is not added------------------------------------------------------------------*/


    }else{
        alert("Add question");
    }
}

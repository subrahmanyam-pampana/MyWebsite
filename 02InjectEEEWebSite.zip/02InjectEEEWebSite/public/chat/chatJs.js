var rightpannel = $("#rightPannel");

function renderDoubts(doc) {
  var imageSource = "waters-3102729__340.jpg";
  var parentDiv = document.createElement("div");
  parentDiv.setAttribute("class", "questionDiv doubt_div");
  parentDiv.setAttribute("data-id", doc.id);

  var questionDiv = document.createElement("div");
  var textBoxDiv = document.createElement("div");
  var chatDiv = document.createElement("div");

  chatDiv.setAttribute("class", "chat");
  /*--------------Question Div---------------------------------*/
  var queText = document.createElement("p");
  var qimage = document.createElement("img");

  queText.innerHTML = doc.data().question;

  qimage.setAttribute("class", "qimage");

  questionDiv.appendChild(queText);
  console.log(doc.data().Dimage);
  if (doc.data().Dimage) {
    qimage.setAttribute("src", doc.data().Dimage);
    qimage.onload = () => {
      questionDiv.appendChild(qimage);
    };
  }

  /*--------------text box Div---------------------------------*/

  $(textBoxDiv).css("position", "relative");
  var coment = document.createElement("input");
  coment.setAttribute("class", "comment_textBox startChat");
  coment.setAttribute("placeholder", "Type your answer.....");

  var sendBtn = document.createElement("i");
  sendBtn.setAttribute("class", "far fa-paper-plane sendBtn");

  var viewChat = document.createElement("i");
  viewChat.setAttribute("class", "far fa-comment-dots viewChat");

  textBoxDiv.appendChild(coment);
  textBoxDiv.appendChild(sendBtn);
  textBoxDiv.appendChild(viewChat);

  $(viewChat).click(() => {
    sendMsgEvent();
  });

  $(coment).keypress(function (e) {
    var key = e.which;
    if (key == 13) {
      sendMsgEvent();
      return false;
    }
  });

  //commenting

  var sendMsgEvent = () => {
    $(chatDiv).show();
    var msghtml = "";
    var closeChat = document.createElement("div");

    if ($(coment).val() != "") {
      var msg = $(coment).val();

      /*-------------------updating comments to db -----------------------------------------*/
      var date = new Date();
      var time = date.toLocaleDateString() + " " + date.toLocaleTimeString();

      msghtml = `<div class="msgText">
      <span class="chat-user">${userName}  ${time}</span><br>
      <p class="textMsg">${msg}</p>
      </div>`;

      db.collection("doubts")
        .doc(doc.id)
        .update({
          comments: firebase.firestore.FieldValue.arrayUnion({
            user: userName,
            comment: $(coment).val(),
            timeStamp: time,
          }),
        })
        .then(() => {
          console.log("comment updated");
        });

      $(messageDiv).append(msghtml);
      $(coment).val("");
    }

    $(chatDiv).append(textBoxDiv);
    coment.focus();
    closeChat.setAttribute("class", "closeChat");
    closeChat.innerHTML = "x";
    textBoxDiv.appendChild(closeChat);

    $(closeChat).click(() => {
      $(parentDiv).append(textBoxDiv);
      $(chatDiv).hide();
      $(textBoxDiv).find(".closeChat").remove();
    });
  };

  $(sendBtn).click(() => {
    sendMsgEvent();
  });

  /*--------------chat Div---------------------------------*/
  var messageDiv = document.createElement("div");
  messageDiv.setAttribute("class", "chatBody");
  chatDiv.appendChild(messageDiv);
  
  if (doc.data().comments) {
    var comments = doc.data().comments;

    for (var i = 0; i < doc.data().comments.length; i++) {

      var divClass = "";
      if (comments[i].user != userName) {
        divClass = "msgText_left";
      } else {
        divClass = "";
      }

      var msghtml = `<div class="msgText ${divClass}">
       <span class="chat-user">${comments[i].user}  ${comments[i].timeStamp}</span><br>
      <p class="textMsg">${comments[i].comment}</p>
      </div>`;

      $(messageDiv).append(msghtml);
    }
  }

  /*--------------appending all divs to parent Div---------------------*/

  parentDiv.appendChild(questionDiv);
  parentDiv.appendChild(textBoxDiv);
  parentDiv.appendChild(chatDiv);

  $(rightpannel).append(parentDiv);
}

var Imagefile;

$("#doubtImageUpload").click(() => {
  let input = document.createElement("input");
  input.type = "file";
  input.click();
  input.onchange = (event) => {
    Imagefile = event.target.files[0];
    console.log(Imagefile);
    var ImageTempUrl = URL.createObjectURL(Imagefile);
    var image = document.createElement("img");
    image.setAttribute("class", "qimage chatImg doubtImage");
    image.src = ImageTempUrl;
    image.onload = () => {
      $("#DoubtQimage").append(image);
      $(".ask_doubt_div").css("border", "1px dashed blue");
    };
  };
});

//posting question
$("#postDoubt").click(() => {
  var subject = "networks";
  //var userName = "subrahmanyam";
  var date = new Date();
  var time = date.toLocaleDateString() + " " + date.toLocaleTimeString();
  db.collection("doubts")
    .add({
      question: $("#doubt_text").val(),
      subject: subject,
      user: userName,
      tmeStamp: time,
    })
    .then((docRef) => {
      // alert("doubt posted with Id:" + docRef.id);
      if (Imagefile) {
        uploadImage(
          "doubts",
          "Dimage",
          "Doubts/" + subject + "/" + docRef.id + "/Qimage",
          Imagefile,
          docRef.id
        );
      }
    });
});

function uploadImage(collection, imageProp, imagePath, file, id) {
  /*-----------------------------Uploading image----------------------------------------------------------------------*/

  var uploadTask = storageRef.child(imagePath).put(file);
  /*------------------------------Showing upload status---------------------------------------------------------------------*/

  uploadTask.on(
    "state_changed",
    (snapshot) => {
      var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
    },
    /*------------------------------on Error ---------------------------------------------------------------------*/
    (error) => {
      alert("Error:" + error);
    },
    /*----------------------------on completion of upload-------------------------------------------------------------------*/
    () => {
      var imageUrl;
      uploadTask.snapshot.ref.getDownloadURL().then((url) => {
        imageUrl = url;
        console.log(imageUrl);

        var props = {};
        props[imageProp] = imageUrl;
        console.log(props);
        db.collection(collection)
          .doc(id)
          .update(props)
          .then(() => {
            alert("image upload successfully with path: " + imageUrl);
          });
      });
    }
  );
}

function updateChat(doc) {
  var comments = doc.data().comments;
  if (comments) {
    var commentUser = comments[comments.length - 1].user;
    if (commentUser != userName) {
      var comment = comments[comments.length - 1].comment;
      var time = comments[comments.length - 1].timeStamp;
      let queDiv = $("#rightPannel").find("[data-id=" + doc.id + "]");
      let chatDiv = $(queDiv).find(".chatBody");

      var html = `<div class="msgText msgText_left">
      <span class="chat-user">${commentUser}  ${time}</span><br>
      <p class="textMsg">${comment}</p>
      </div>`;

      $(chatDiv).append(html);
      console.log(commentUser);
    }
  }
}

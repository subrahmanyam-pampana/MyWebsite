var rightpannel =$("#rightPannel");

function renderDoubts(){
 var imageSource ="waters-3102729__340.jpg";
var parentDiv = document.createElement('div');
parentDiv.setAttribute('class','questionDiv doubt_div');

var  questionDiv = document.createElement('div');
var  textBoxDiv = document.createElement('div');
var  chatDiv = document.createElement('div');
/*--------------Question Div---------------------------------*/
var queText = document.createElement('p');
var qimage = document.createElement('img');

queText.innerHTML ="your new question here";

qimage.setAttribute('class','qimage');
qimage.setAttribute('src',imageSource);

questionDiv.appendChild(queText);
questionDiv.appendChild(qimage);

/*--------------text box Div---------------------------------*/
var coment = document.createElement('input');

coment.setAttribute('class','comment_textBox startChat');
coment.setAttribute('placeholder','Type your answer.....');

$(textBoxDiv).click(()=>{

    $(chatDiv).show();
  //  console.log($(".startChat").html());
    });

textBoxDiv.appendChild(coment);

/*--------------chat Div---------------------------------*/
var messageDiv = document.createElement('div');
var msgText = document.createElement('p');
var msgImg = document.createElement('img');

msgImg.setAttribute('class','qimage chatImg');
msgImg.setAttribute('src',imageSource);

messageDiv.appendChild(msgText);
messageDiv.appendChild(msgImg);

/*--------------appending all divs to parent Div---------------------*/

parentDiv.appendChild(questionDiv);
parentDiv.appendChild(textBoxDiv);
parentDiv.appendChild(chatDiv);

$(rightpannel).append(parentDiv);
}
renderDoubts();
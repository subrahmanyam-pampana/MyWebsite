var rightpannel = $("#rightPannel");

function renderDoubts(doc) {
  var imageSource = "waters-3102729__340.jpg";
  var parentDiv = document.createElement("div");
  parentDiv.setAttribute("class", "questionDiv doubt_div");
  parentDiv.setAttribute("data-id", doc.id);

  var questionDiv = document.createElement("div");
  var textBoxDiv = document.createElement("div");
  var chatDiv = document.createElement("div");

  /*--------------user details--------------------------------*/
  var userDetailsDiv = ` <div class="userIconDiv">
                        <img class="circle userIcon"  src="waters-3102729__340.jpg" alt="userIcon">
                        <p class="DoubtpostedUser">${doc.data().user}</p>
                        </div>`;

  $(parentDiv).append(userDetailsDiv);

  chatDiv.setAttribute("class", "chat");
 
  /*--------------Question Div---------------------------------*/
  
  var queText = document.createElement("p");
  var qimage = document.createElement("img");

  queText.innerHTML = doc.data().question;

  qimage.setAttribute("class", "qimage");

  questionDiv.appendChild(queText);

  /*--------------text box Div---------------------------------*/

  $(textBoxDiv).css("position", "relative");
  var coment = document.createElement("input");
  coment.setAttribute("class", "comment_textBox startChat");
  coment.setAttribute("placeholder", "Type your answer.....");

  $(coment).focus((e) => {
    $(".typeDoubtDiv").hide();
    $(".addDoubtBtn i").text("add");
  });

  var sendBtn = document.createElement("i");
  sendBtn.setAttribute("class", "far fa-paper-plane sendBtn");

  var viewChat = document.createElement("i");
  viewChat.setAttribute("class", "far fa-comment-dots viewChat");
  viewChat.setAttribute("state", "hide");

  textBoxDiv.appendChild(coment);
  textBoxDiv.appendChild(sendBtn);
  textBoxDiv.appendChild(viewChat);

  $(viewChat).click(() => {
    var state = $(viewChat).attr("state");
    if (state == "hide") {
      sendMsgEvent();
      $(viewChat).attr("state", "view");
    } else {
      $(chatDiv).hide();
      $(parentDiv).append(textBoxDiv);
      $(viewChat).attr("state", "hide");
    }
  });

  $(coment).keypress(function (e) {
    var key = e.which;
    if (key == 13) {
      sendMsgEvent();
      return false;
    }
  });

  //commenting

  var sendMsgEvent = () => {
    $(chatDiv).show();
    var msghtml = "";
    // var closeChat = document.createElement("div");

    if ($(coment).val() != "") {
      var msg = $(coment).val();

      /*-------------------updating comments to db -----------------------------------------*/
      var date = new Date();
      var time = date.toLocaleDateString() + " " + date.toLocaleTimeString();

      msghtml = `<div class="msgText">
      <span class="chat-user">${userName}  ${time}</span><br>
      <p class="textMsg">${msg}</p>
      </div>`;

      db.collection("doubts")
        .doc(doc.id)
        .update({
          comments: firebase.firestore.FieldValue.arrayUnion({
            user: userName,
            comment: $(coment).val(),
            timeStamp: time,
          }),
        })
        .then(() => {
          //e.log("comment updated");
        });

      $(messageDiv).append(msghtml);
      $(coment).val("");
    }

    $(chatDiv).append(textBoxDiv);
    coment.focus();
  };

  $(sendBtn).click(() => {
    sendMsgEvent();
  });

  /*--------------chat Div---------------------------------*/
  var messageDiv = document.createElement("div");
  messageDiv.setAttribute("class", "chatBody");
  chatDiv.appendChild(messageDiv);

  if (doc.data().comments) {
    var comments = doc.data().comments;

    for (var i = 0; i < doc.data().comments.length; i++) {
      var divClass = "";
      if (comments[i].user != userName) {
        divClass = "msgText_left";
      } else {
        divClass = "";
      }

      var msghtml = `<div class="msgText ${divClass}">
       <span class="chat-user">${comments[i].user}  ${comments[i].timeStamp}</span><br>
      <p class="textMsg">${comments[i].comment}</p>
      </div>`;

      $(messageDiv).append(msghtml);
    }
  }

  /*--------------appending all divs to parent Div---------------------*/

  if (doc.data().Dimage) {
    qimage.setAttribute("src", doc.data().Dimage);
    qimage.onload = () => {
      questionDiv.appendChild(qimage);
      parentDiv.appendChild(questionDiv);
      parentDiv.appendChild(textBoxDiv);
      parentDiv.appendChild(chatDiv);
      $(rightpannel).append(parentDiv);
    };
  } else {
    parentDiv.appendChild(questionDiv);
    parentDiv.appendChild(textBoxDiv);
    parentDiv.appendChild(chatDiv);
    $(rightpannel).append(parentDiv);
  }
}

var Imagefile;
//show image in the UI

$("#doubtImageUpload").click(() => {
  let input = document.createElement("input");
  input.type = "file";
  input.click();
  input.onchange = (event) => {
    Imagefile = event.target.files[0];
    // console.log(Imagefile);
    var ImageTempUrl = URL.createObjectURL(Imagefile);
    var imgDiv = document.createElement("div");
    imgDiv.setAttribute("class", "col s6");

    var image = document.createElement("img");
    image.setAttribute("class", "qimage chatImg doubtImage");
    image.src = ImageTempUrl;

    image.onload = () => {
      $(imgDiv).append(image);
      $("#Doubt_Qimage").append(imgDiv);

      $(".typeDoubtDiv").addClass("postInst");
    };
  };
});

//posting question

$("#postDoubt").click(() => {
  var subject = "networks";
  var question = $("#doubt_text").val();
  if (!question || !Imagefile) {
    alert("please type your question!");
    return;
  }

  var date = new Date();
  var time = date.toLocaleDateString() + " " + date.toLocaleTimeString();

  var imagePath = "Doubts/" + subject + "/" + Date.now() + "/Dimage";

  var uploadTask = storageRef.child(imagePath).put(Imagefile);

  uploadTask.on(
    "state_changed",
    (snapshot) => {
      var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
    },
    (error) => {
      console.log("Error:" + error);
    },
    () => {
      uploadTask.snapshot.ref.getDownloadURL().then((imageUrl) => {
        // console.log(imageUrl);

        db.collection("doubts")
          .add({
            question: question,
            subject: subject,
            user: userName,
            tmeStamp: time,
            Dimage: imageUrl,
          })
          .then((docRef) => {
            alert("Question posted");
          });
      });
    }
  );

  $("#Doubt_Qimage").empty();
  $("#doubt_text").val("");
  $(".typeDoubtDiv").hide();
  $(".addDoubtBtn i").text("add");
});

//updating chat

function updateChat(doc) {
  var comments = doc.data().comments;
  if (comments) {
    var commentUser = comments[comments.length - 1].user;
    if (commentUser != userName) {
      var comment = comments[comments.length - 1].comment;
      var time = comments[comments.length - 1].timeStamp;
      let queDiv = $("#rightPannel").find("[data-id=" + doc.id + "]");
      let chatDiv = $(queDiv).find(".chatBody");

      var html = `<div class="msgText msgText_left">
      <span class="chat-user">${commentUser}  ${time}</span><br>
      <p class="textMsg">${comment}</p>
      </div>`;
      $(chatDiv).append(html);
    }
  }
}

//inreasing height of ask doubt div on click of input field

$(".addDoubtBtn").click((e) => {
  if ($(e.target).text() == "add") {
    $(".typeDoubtDiv").show();
    $(".addDoubtBtn i").text("clear");
  } else if ($(e.target).text() == "clear") {
    $("#Doubt_Qimage").empty();
    $("#doubt_text").val("");
    $(".typeDoubtDiv").hide();
    $(".addDoubtBtn i").text("add");
  }
});

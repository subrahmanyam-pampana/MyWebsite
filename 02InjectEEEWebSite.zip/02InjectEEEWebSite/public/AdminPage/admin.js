//adding new question
//if request.auth != null
var storageRef = storage.ref();

var file = {
    qfile: '',
    sfile: ''
};
var question = {
    qid: ""
}
var form = document.getElementById("addNewQuestionForm");
form.addEventListener('submit', (event) => {
    event.preventDefault();
    var list = $("#add_opt_list li");
    console.log(list);
    var options = [];
    var answer = ''
    if (list.length != '') {
        for (let i = 0; i < list.length; i++) {
            options.push($(list).eq(i).find("input").val());
        }
        answer = form.answer.value;
    } else {
        options = "NA";
        answer = form.netAnswer.value;
    }

    console.log(options);

    db.collection('questions').add({
        question: form.question.value,
        options: options,
        answer: form.answer.value,
        solution: form.solution.value,
        subject: form.subject.value,
        type: form.type.value,
        year: form.year.value
    }).then((docRef) => {
        alert("question added successfully with doc id: " + docRef.id);
        if(file.qfile){
           
            uploadFile("Qimage",docRef.id+"_Qimage",file.qfile,docRef.id)
        }

        if(file.sfile){
            uploadFile("Simage",docRef.id+"_Simage",file.sfile,docRef.id)
        }
        
    }).catch((error) => {
        alert("Error occured while Addeding new document. Error: " + error);
    });

});


$("#QimageBtn").click(() => {

    let input = document.createElement('input');
    input.type = 'file';
    input.click();
    input.onchange = (event) => {
        /*----------------------------getting the image-----------------------------------------------------------------------*/
        file.qfile = event.target.files[0];
        console.log(file);
    }

    // var imagesRef = storageRef.child('images');

    // var imageName = question.qid + "_Qimage";

});

$("#SimageBtn").click(() => {

    let input = document.createElement('input');
    input.type = 'file';
    input.click();
    input.onchange = (event) => {
        /*----------------------------getting the image-----------------------------------------------------------------------*/
        file.sfile = event.target.files[0];
        console.log(file);
    }

    // var imagesRef = storageRef.child('images');

    // var imageName = question.qid + "_Qimage";

});


$("#add_opt_btn").click(() => {
    let ul = document.createElement('li');
    let input = document.createElement('input');
    let removeBtn = document.createElement('i');
    removeBtn.setAttribute('class', 'fas fa-times undoChange remove');
    $(removeBtn).click(() => {
        $(ul).remove();
        console.log("remove");
    });
    $(ul).append(input);
    $(ul).append(removeBtn);
    $("#add_opt_list").append(ul);

});

function uploadFile(imageProp,imagePath,file,id) {     
    /*-----------------------------Uploading image----------------------------------------------------------------------*/

        var uploadTask = storageRef.child('images/'+imagePath).put(file);
        /*------------------------------Showing upload status---------------------------------------------------------------------*/

        uploadTask.on('state_changed', (snapshot) => {
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            $("#uploadStatus").text("uploaded " + progress + "%");

        },
            /*------------------------------on Error ---------------------------------------------------------------------*/
            (error) => {
                alert("Error:" + error);
            },
            /*----------------------------on completion of upload-------------------------------------------------------------------*/
            () => {
                var imageUrl;
                uploadTask.snapshot.ref.getDownloadURL().then((url) => {
                    imageUrl = url;
                    console.log(imageUrl);
                   
                        var props  = {  
                        }
                        props[imageProp]=imageUrl;
                        console.log(props);
                        db.collection('questions').doc(id).update(props).then(() => {
                            alert("image upload successfully with path: " + imageUrl);
                        });
                });
            }
        );
    
} 

$("#type").change((e) => {
    let type = $(e.target).val();
    if (type == "mcq") {
        $("#netTypeAnswer").hide();
        $("#add_opt_btn").show();
        $("#add_opt_list").show();
        $("#answer").show();
    } else if (type == "netType") {
        $("#add_opt_btn").hide();
        $("#add_opt_list").empty();
        $("#answer").hide();
        $("#netTypeAnswer").show();

    }
});
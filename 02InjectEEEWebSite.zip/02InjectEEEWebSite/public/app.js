// var questionNum = 1;
var appData = {};

var admin = false;

window.onload = () => {
  fetch("data.json")
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      appData = data;
      insertData();
    });

  var insertData = () => {
    if (searchParams.get("filterName")) {
      var filterName = searchParams.get("filterName");
      var filterVal = searchParams.get("filterValue");
      filterQuestions(filterName, filterVal);
      searchParams.delete("filterName");
      searchParams.delete("filterValue");
    } else {
      appData.subjects.forEach((subject) => {
        getdata(subject, subject);
      });
    }
  };
};

var setupUI = (user) => {
  if (user) {
    //showing user details
    db.collection("users")
      .doc(user.uid)
      .get()
      .then((doc) => {
        userName = doc.data().userName;
        $(".userName").text(userName);
        $(".email").text(user.email);
      });

    $(".logged-in").show();
    $(".logged-out").hide();
  } else {
    $(".logged-in").hide();
    $(".logged-out").show();
  }
};

function fnshowHide(e) {
  if ($(e).val() == "H") {
    $(e).siblings(".solution-div").show();
    $(e).text("Hide Solution");
    $(e).val("S");
  } else if ($(e).val() == "S") {
    $(e).siblings(".solution-div").hide();
    $(e).text("View Solution");
    $(e).val("H");
  }
}

function fnSelectOption(e) {
  $(e).siblings().removeClass("selectedOption");
  $(e).addClass("selectedOption");
}

/*------------------------fnrenderQuetions-----------------------------------------------------------*/
function fnrenderQuetions(doc, parentId, questionNum) {
  if (doc) {
    if (doc.data().type == "mcq") {
      var opnNum = ["A", "B", "C", "D", "F", "G", "H"];

      //question div
      let div = document.createElement("div");
      div.setAttribute("class", `questionDiv ${doc.id}`);
      div.setAttribute("id", doc.id);

      //delete tag
      let delTag = document.createElement("p");
      delTag.setAttribute("class", "delQuetion");
      delTag.setAttribute("onclick", "fnDelQuestion(this)");
      delTag.innerHTML = "x";

      //question number tag
      let question = document.createElement("div");
      question.setAttribute("name", "question");

      let queTextDiv = document.createElement("div");
      question.setAttribute("class", "queTextDiv");

      // let qno = document.createElement("span");
      // qno.innerHTML = questionNum;
      // qno.setAttribute("class", "option-text qno");
      // queTextDiv.appendChild(qno);

      //question text tag
      let queText = document.createElement("span");
      queText.innerHTML = doc.data().question;
      $(queText).dblclick(() => {
        fnEditQueText(queText);
      });
      queTextDiv.appendChild(queText);
      question.appendChild(queTextDiv);

      //table
      var table = document.createElement("table");
      table.setAttribute("answer", doc.data().answer);
      var options = doc.data().options;

      options.forEach((optn, index) => {
        let optnTr = document.createElement("tr");
        optnTr.setAttribute("class", "option-tr");
        optnTr.setAttribute("option_value", opnNum[index]);
        optnTr.setAttribute("onclick", "fnSelectOption(this)");

        //option lable
        let optnTd1 = document.createElement("td");
        optnTd1.setAttribute("class", "option-text");
        optnTd1.innerHTML = opnNum[index];
        optnTr.appendChild(optnTd1);

        //option text
        let optnTd2 = document.createElement("td");
        optnTd2.innerHTML = optn;
        optnTd2.setAttribute("class", "option_text_lab");
        optnTr.appendChild(optnTd2);
        table.appendChild(optnTr);

        $(optnTd2).dblclick(() => {
          editOption(optnTd2, doc.id);
        });
      });

      //topic name
      let topicNameDiv = document.createElement("div");
      topicNameDiv.setAttribute("class", "addTag topicName");
      topicNameDiv.innerHTML = doc.data().topic;
      $(topicNameDiv).click(() => {
        // filterQuestions('topic', doc.data().topic);
        openNewWindow("topic", doc.data().topic);
      });

      //year div
      let yearDiv = document.createElement("div");
      yearDiv.setAttribute("class", "addTag");
      yearDiv.innerHTML = doc.data().year;
      $(yearDiv).click(() => {
        // filterQuestions('year', doc.data().year);
        openNewWindow("year", doc.data().year);
      });

      //check button
      let checkbtn = document.createElement("button");
      checkbtn.setAttribute("onclick", "fnCheckAnswer(this)");
      checkbtn.setAttribute("class", "button view");
      checkbtn.innerHTML = "Check Answer";

      //view solution button
      let viewbtn = document.createElement("button");
      viewbtn.setAttribute("class", "button viewSolbtn");
      viewbtn.setAttribute("value", "H");
      viewbtn.innerHTML = "View Solution";
      viewbtn.setAttribute("onclick", "fnshowHide(this)");

      //change answer button
      let AnswerDiv = document.createElement("div");
      $(AnswerDiv).css("display", "inline");
      let changeAnswer = document.createElement("button");
      changeAnswer.setAttribute("class", "button");
      changeAnswer.innerHTML = "Change Answer";

      if(!admin){
        changeAnswer.style.display='none';
      }

      $(changeAnswer).click(() => {
        updateAnswer(changeAnswer, doc.id, table);
      });
      if (admin) AnswerDiv.appendChild(changeAnswer);

      //add topic button
      let topicDiv = document.createElement("div");

      let topicBtn = document.createElement("button");
      topicBtn.setAttribute("class", "button");
      topicBtn.innerHTML = "Add Topic";
      if(!admin){
        topicBtn.style.display='none';
      }

      $(topicBtn).click(() => {
        addTopic(topicBtn, doc.id, topicNameDiv);
      });
      if (admin) topicDiv.appendChild(topicBtn);

      //solution div
      let soldiv = document.createElement("div");
      soldiv.setAttribute("class", "solution-div");
      // soldiv.setAttribute('answer', doc.data().answer);

      let solPtag = document.createElement("p");
      solPtag.setAttribute("name", "solution");

      //solution lable tag
      let solLabTag = document.createElement("span");
      solLabTag.innerHTML = "Solution: ";
      solLabTag.setAttribute("class", "solLab");

      //sulution span tag
      let solStag = document.createElement("span");
      solStag.innerHTML = doc.data().solution;
      $(solStag).dblclick(() => {
        fnEditSlnText(solStag);
      });

      //appending to solution p tag
      solPtag.appendChild(solLabTag);
      solPtag.appendChild(solStag);

      let noteTag = document.createElement("textarea");
      noteTag.setAttribute("class", "userNote");
      noteTag.setAttribute("placeholder", "take your notes here");
      noteTag.setAttribute("value", doc.data().note);

      soldiv.appendChild(solPtag);

      //solotion image
      if (doc.data().Simage) {
        let simage = document.createElement("img");
        simage.setAttribute("src", doc.data().Simage);
        simage.setAttribute("class", "simage");
        simage.setAttribute("imageName", doc.data().SimageName);
        soldiv.appendChild(simage);

        $(simage).dblclick(() => {
          browseFiles().then((files) => {
            var ImageTempUrl = URL.createObjectURL(files[0]);
            simage.setAttribute("src", ImageTempUrl);

            var imagePath =
              "QuestionImages/" +
              doc.data().subject +
              "/" +
              doc.id +
              "/" +
              "Simage";
            uploadFile("Simage", "SimageName", imagePath, files[0], doc.id);
          });
        });
      }

      soldiv.appendChild(noteTag);

      //appending all the elements to div
      div.appendChild(delTag);
      div.appendChild(question);

      //question image
      if (doc.data().Qimage) {
        let qimage = document.createElement("img");
        qimage.setAttribute("src", doc.data().Qimage);
        qimage.setAttribute("class", "qimage");
        qimage.setAttribute("imageName", doc.data().QimageName);
        question.appendChild(qimage);

        $(qimage).dblclick(() => {
          browseFiles().then((files) => {
            var ImageTempUrl = URL.createObjectURL(files[0]);
            qimage.setAttribute("src", ImageTempUrl);

            var imagePath =
              "QuestionImages/" +
              doc.data().subject +
              "/" +
              doc.id +
              "/" +
              "Qimage";
            uploadFile("Qimage", "QimageName", imagePath, files[0], doc.id);
          });
        });
      }
      /*-------------------------Chat div----------------------------------------------------------------*/
      var liked = "none",
        likedClr = "rgba(0,0,0,0.87)",
        likes='No',
        saved='none',
        savedClr='rgba(0,0,0,0.87)';
      
        savedQues.forEach((ele)=>{ if(ele== doc.id){ saved='saved'; savedClr='blue'}})

      if (doc.data().likedUsers && doc.data().likes) {
        doc.data().likedUsers.forEach((ele) => {
          if (ele == userName) {
            liked = "liked";
            likedClr = "red";
          }
          likes= doc.data().likes;
        });
      }

      var chatDiv = `
      <div class='queBtmNav'>
      <div class="divider"></div>
         <table>
          <tr class='row'>
             <td class ='col s4'><span class="likes">${likes} Likes</span></td>
             <td class ='col s4'><span>Comments</span></td>
          </tr>
         </table>
                <div class='iconsBar'>
                <table>
                 <tr class='row'>
                   <td class ='col s4'> <i class='material-icons Addlike' style="color:${likedClr}" qid="${doc.id}" state='${liked}'>favorite_border<i></td>
                   <td class ='col s4'> <i class="far fa-comment-dots ShowChat" state="hide" aria-hidden="true"></i> </td>
                   <td class ='col s4'> <i class='material-icons BookMarkQue' style="color:${savedClr}" subject="${doc.data().subject}" qid="${doc.id}" state="${saved}">bookmark_border<i> </td>
                 </tr>
                </table>
             </div></div>`;
      {
        /* <i class="material-icons" state="hide" aria-hidden="true">chat_bubble_outline</i>  */
      }
      div.appendChild(table);
      if (doc.data().topic) div.appendChild(topicNameDiv);
      if (doc.data().year) div.appendChild(yearDiv);
      div.appendChild(checkbtn);
      div.appendChild(viewbtn);
      div.appendChild(AnswerDiv);
      div.appendChild(topicDiv);
      div.appendChild(soldiv);
      $(div).append(chatDiv);

      let parent = document.getElementById(parentId);

      parent.appendChild(div);
    }
  } else {
    $("#rightPannel").html("");
  }
}

/*------------------------edit options-----------------------------------------------------------*/

function editOption(optnTd2, id) {
  let text = $(optnTd2).text();
  let parent = $(optnTd2).parent();
  let table = $(optnTd2).parents("table");

  let input = document.createElement("input");
  input.value = text;
  $(parent).append(input);

  let saveTag = document.createElement("i");
  saveTag.setAttribute("class", "fas fa-check undoChange");

  let undoTag = document.createElement("i");
  undoTag.setAttribute("class", "fas fa-times undoChange");

  $(saveTag).css({
    width: "22px",
    position: "static",
  });

  $(undoTag).css({
    width: "22px",
    position: "static",
  });

  $(parent).append(saveTag);
  $(parent).append(undoTag);

  $(undoTag).click(() => {
    $(input).remove();
    $(saveTag).remove();
    $(undoTag).remove();
    $(parent).append(optnTd2);
    $(optnTd2).dblclick(() => {
      editOption(optnTd2, id);
    });
  });

  $(saveTag).click(() => {
    let optn = [];
    optnTd2.innerHTML = $(input).val();
    $(parent).append(optnTd2);
    $(optnTd2).dblclick(() => {
      editOption(optnTd2, id);
    });

    $(input).remove();
    $(saveTag).remove();
    $(undoTag).remove();

    $(table)
      .find(".option_text_lab")
      .each((i, e) => {
        optn.push($(e).text());
      });

    if (text != $(input).val()) {
      db.collection("questions")
        .doc(id)
        .update({
          options: optn,
        })
        .then(() => {
          displayMsg("S", "Option updated successfully ");
        });
    }
  });

  $(optnTd2).remove();
}

/*------------------------getdata-----------------------------------------------------------*/
function getdata(subject, parentId) {
  $(loader).show();
  var questionNum = 1;
  $(parentId).empty();
  if (subject == "all") {
    db.collection("questions")
      .orderBy("year")
      .get()
      .then((snapshot) => {
        $(loader).hide();
        snapshot.docs.forEach((doc) => {
          fnrenderQuetions(doc, parentId, questionNum);
          questionNum++;
        });
      });
  } else {
    db.collection("questions")
      .where("subject", "==", subject)
      .orderBy("question")
      .get()
      .then((snapshot) => {
        $(loader).hide();
        snapshot.docs.forEach((doc) => {
          fnrenderQuetions(doc, parentId, questionNum);
          questionNum++;
        });
      });
  }
}
/*------------------------openNewWindow------------------------------------------------------------*/

function openNewWindow(filterParam, value) {
  window.open(
    location.href + "?filterName=" + filterParam + "&filterValue=" + value
  );
}

/*------------------------filterQuestions------------------------------------------------------------*/
function filterQuestions(filterParam, value) {
  if (filterParam && value) {
    db.collection("questions")
      .where(filterParam, "==", value)
      .orderBy("question")
      .get()
      .then((snapshot) => {
        $(loader).hide();
        snapshot.docs.forEach((doc) => {
          fnrenderQuetions(doc);
        });
      })
      .catch((error) => {
        displayMsg("E", "Error: " + error);
        console.log("Error: " + error);
      });
  }
}

/*------------------------Add topic------------------------------------------------------------*/
function addTopic(topicRef, id, topicNameDiv) {
  var parentDiv = $(topicRef).parent();

  $(parentDiv).attr("clicked", "No");

  if ($(parentDiv).attr("clicked") == "Yes") {
    return false;
  }

  $(parentDiv).attr("clicked", "Yes");
  var TopicInput = document.createElement("input");
  TopicInput.value = $(topicNameDiv).text();
  $(TopicInput).css("width", "75%");

  let saveTag = document.createElement("i");
  saveTag.setAttribute("class", "fas fa-check undoChange");

  let undoTag = document.createElement("i");
  undoTag.setAttribute("class", "fas fa-times undoChange");
  $(saveTag).css({
    left: "0px",
    top: "0px",
  });
  $(undoTag).css({
    left: "0px",
    top: "0px",
  });

  $(parentDiv).append(TopicInput);
  $(parentDiv).append(saveTag);
  $(parentDiv).append(undoTag);

  $(saveTag).click(() => {
    var topic = $(TopicInput).val();
    db.collection("questions")
      .doc(id)
      .update({
        topic: topic,
      })
      .then((docRef) => {
        displayMsg("S", "Topic updated with value: " + topic);

        $(topicNameDiv).text(topic);
      })
      .catch((error) => {
        displayMsg("E", "Error: " + error);
        console.log(error);
      });
    $(saveTag).remove();
    $(undoTag).remove();
    $(TopicInput).remove();
    $(parentDiv).attr("clicked", "No");
  });

  $(undoTag).click(() => {
    $(saveTag).remove();
    $(undoTag).remove();
    $(TopicInput).remove();
    $(parentDiv).attr("clicked", "No");
  });
}

/*------------------------updateAnswer-----------------------------------------------------------*/

function updateAnswer(changeAnswer, id, table) {
  var parentDiv = $(changeAnswer).parent();

  $(parentDiv).attr("clicked", "No");

  if ($(parentDiv).attr("clicked") == "Yes") {
    return false;
  }
  $(parentDiv).attr("clicked", "Yes");
  var AnswerInput = document.createElement("input");
  AnswerInput.value = $(table).attr("answer");

  let saveTag = document.createElement("i");
  saveTag.setAttribute("class", "fas fa-check undoChange");

  let undoTag = document.createElement("i");
  undoTag.setAttribute("class", "fas fa-times undoChange");
  $(saveTag).css({
    left: "0px",
    top: "0px",
  });
  $(undoTag).css({
    left: "0px",
    top: "0px",
  });

  $(parentDiv).append(AnswerInput);
  $(parentDiv).append(saveTag);
  $(parentDiv).append(undoTag);

  $(saveTag).click(() => {
    var answer = $(AnswerInput).val().toUpperCase();
    db.collection("questions")
      .doc(id)
      .update({
        answer: answer,
      })
      .then((docRef) => {
        displayMsg("S", "Answer updated with value: " + answer);
        $(table).attr("answer", answer);
      })
      .catch((error) => {
        displayMsg("E", "Error: " + error);
        console.log(error);
      });
    $(saveTag).remove();
    $(undoTag).remove();
    $(AnswerInput).remove();
    $(parentDiv).attr("clicked", "No");
  });

  $(undoTag).click(() => {
    $(saveTag).remove();
    $(undoTag).remove();
    $(AnswerInput).remove();
    $(parentDiv).attr("clicked", "No");
  });
}

/*------------------------fnDelQuestion-----------------------------------------------------------*/
function fnDelQuestion(e) {
  if (confirm("Do you want to delete question")) {
    let id = $(e).parent().attr("id");
    var images = $(e).parent().find("img");

    if (id) {
      db.collection("questions")
        .doc(id)
        .delete()
        .then(() => {
          $(e).parent().remove();

          images.each((index, ele) => {
            storageRef
              .child($(ele).attr("imagename"))
              .delete()
              .then(() => {
                console.log("images deleted");
              });
          });
        })
        .catch((error) => {
          alert("Error: " + error);
        });
    }
  }
}

/*------------------------fnEditQueText-----------------------------------------------------------*/

function fnEditQueText(e) {
  var text = $(e).text();

  var parentDiv = document.createElement("div");
  parentDiv.setAttribute("class", "edit-par-div");

  var inputTag = document.createElement("textarea");
  inputTag.value = text;
  inputTag.setAttribute("class", "editTextArea");

  let saveTag = document.createElement("i");
  saveTag.setAttribute("class", "fas fa-check undoChange");

  $(saveTag).click(() => {
    fnSaveQueChages(saveTag);
  });

  let undoTag = document.createElement("i");
  undoTag.setAttribute("class", "fas fa-times undoChange");

  $(undoTag).click(() => {
    fnUndoQueChages(event, text);
  });

  parentDiv.appendChild(inputTag);
  parentDiv.appendChild(saveTag);
  parentDiv.appendChild(undoTag);

  $(e).parent().append(parentDiv);
  $(e).remove();
}

function fnSaveQueChages(e) {
  var text = $(e).siblings(".editTextArea").val();
  var id = $(e).parents("div .questionDiv").attr("id");
  var spanTag = document.createElement("span");
  spanTag.innerHTML = text;

  $(spanTag).dblclick(() => {
    fnEditQueText(spanTag);
  });

  db.collection("questions")
    .doc(id)
    .update({
      question: text,
    })
    .then((docRef) => {
      displayMsg("S", "Quetion updated successfully ");
    })
    .catch((error) => {
      displayMsg("E", "Error");
      console.log("Error: " + error);
    });

  $(e).parent().append(spanTag);
  $(e).parent().parent().append(spanTag);
  $(e).parent().remove();
}

function fnUndoQueChages(event, text) {
  var e = event.target;
  var spanTag = document.createElement("span");
  spanTag.innerHTML = text;

  $(spanTag).dblclick(() => {
    fnEditQueText(spanTag);
  });
  $(e).parent().parent().append(spanTag);
  $(e).parent().remove();
}

/*------------------------edit solution text-----------------------------------------------------------*/

function fnEditSlnText(e) {
  var text = $(e).text();

  var parentDiv = document.createElement("div");
  parentDiv.setAttribute("class", "edit-par-div");

  var inputTag = document.createElement("textarea");
  inputTag.value = text;
  inputTag.setAttribute("class", "editTextArea");

  let saveTag = document.createElement("i");
  saveTag.setAttribute("class", "fas fa-check undoChange");

  $(saveTag).click(() => {
    fnSaveSlnChages(saveTag);
  });
  let undoTag = document.createElement("i");
  undoTag.setAttribute("class", "fas fa-times undoChange");

  $(undoTag).click(() => {
    fnUndoSlnChages(event, text);
  });

  parentDiv.appendChild(inputTag);
  parentDiv.appendChild(saveTag);
  parentDiv.appendChild(undoTag);

  $(e).parent().append(parentDiv);
  $(e).remove();
}

function fnSaveSlnChages(e) {
  var text = $(e).siblings(".editTextArea").val();
  var id = $(e).parents("div .questionDiv").attr("id");
  var spanTag = document.createElement("span");
  spanTag.innerHTML = text;

  $(spanTag).dblclick(() => {
    fnEditSlnText(spanTag);
  });

  db.collection("questions")
    .doc(id)
    .update({
      solution: text,
    })
    .then((docRef) => {
      displayMsg("S", "Solution updated successfully ");
    })
    .catch((error) => {
      displayMsg("E", "Error");
      console.log("Error: " + error);
    });

  $(e).parent().append(spanTag);
  $(e).parent().parent().append(spanTag);
  $(e).parent().remove();
}

function fnUndoSlnChages(event, text) {
  var e = event.target;
  var spanTag = document.createElement("span");
  spanTag.innerHTML = text;

  $(spanTag).dblclick(() => {
    fnEditSlnText(spanTag);
  });
  $(e).parent().parent().append(spanTag);
  $(e).parent().remove();
}

/*------------------------Check answer----------------------------------------------------------*/

function fnCheckAnswer(element) {
  var e = $(element).siblings("table").find(".selectedOption");

  let selOptn = $(e).attr("option_value");
  let answer = $(e).parent("table").attr("answer");

  if (selOptn != answer) {
    $(e).css("background-color", "rgba(255, 3, 0, .17)");
    $(e).find(".option-text").css("background-color", "red");
    $(e).find(".option_text_lab").css("color", "red");
  }

  var rows = $(e).parent().find("tr");

  for (let i = 0; i < rows.length; i++) {
    let optn = $(rows[i]).attr("option_value");

    if (optn == answer) {
      $(rows[i]).css("background-color", "rgba(0,255,109,.17)");
      $(rows[i]).find(".option_text_lab").css("color", "green");
      $(rows[i]).find(".option-text").css("background-color", "green");
    }
  }
}

/*------------------------display messages----------------------------------------------------------*/

function displayMsg(type, msg) {
  $("#infoMsg").text(msg);
  if (type == "E") {
    $("#infoMsg").css({
      "background-color": "red",
      color: "red",
      display: "block",
    });
  } else if (type == "S") {
    $("#infoMsg").css({
      "background-color": "#00ff141f",
      color: "green",
      display: "block",
    });
  }

  setTimeout(() => {
    $("#infoMsg").hide();
  }, 5000);
}

/*------------------------materialized css modal initialization-----------------------------------------*/

document.addEventListener("DOMContentLoaded", function () {
  var modals = document.querySelectorAll(".modal");
  M.Modal.init(modals);
});

/*------------------------Home page js----------------------------------------------------------*/
$(document).ready(function () {
  $(".got-btn").click((e) => {
    var tabId = $(e.target).attr("tabId");
    $(".mobile-bottom-nav .bottom-nav-btn").removeClass("green-text");
    $(".mobile-bottom-nav .bottom-nav-btn[tabId='" + tabId + "']").addClass(
      "green-text"
    );

    var subject = $(e.target).parent().attr("subject");

    $("#pyqTopNav li").each((i, e) => {
      if ($(e).attr("class") == subject) {
        $(e).click();
      }
    });
    $(".data-tabs").hide();
    $(tabId).show();
  });
});

/*--------------Add like------------------------------------*/

$(document).on("click", ".Addlike", (e) => {
  var btn = e.target;
  var id = $(btn).attr("qid");
  console.log(id);
  if ($(btn).attr("state") == "none") {
  
    // $(btn).attr("state", "liked");
    // $(btn).css({ color: "red" });

    $(`.${id} .Addlike`).attr("state", "liked");
    $(`.${id} .Addlike`).css({ color: "red" });

    // $(`#bookMark #${id} .Addlike`).attr("state", "liked");
    // $(`#bookMark #${id} .Addlike`).css({ color: "red" });

    db.collection("questions")
      .doc(id)
      .update({
        likes: firebase.firestore.FieldValue.increment(1),
        likedUsers: firebase.firestore.FieldValue.arrayUnion(userName),
      })
      .then(() => {
        console.log("like added");

        db.collection("questions").doc(id).get().then(doc=>{
         $(`.${id} .likes`).text(doc.data().likes+" Likes"); 
        })

      });

      
  } else if ($(btn).attr("state") == "liked") {

    $(btn).attr("state", "none");
    $(btn).css({ color: "rgba(0,0,0,0.87)" });

    $(`.${id} .Addlike`).attr("state", "none");
    $(`.${id} .Addlike`).css({ color: "rgba(0,0,0,0.87)"});

    db.collection("questions")
      .doc(id)
      .update({
        likes: firebase.firestore.FieldValue.increment(-1),
        likedUsers: firebase.firestore.FieldValue.arrayRemove(userName),
      })
      .then(() => {
        db.collection("questions").doc(id).get().then(doc=>{
          $(`.${id} .likes`).text(doc.data().likes+" Likes"); 
         })
      });
  }
});

/*--------------Save question------------------------------------*/
$(document).on('click','.BookMarkQue',(e)=>{

var qid =$(e.target).attr("qid");
var subject =$(e.target).attr("subject");

if($(e.target).attr("state")=="none"){

  db.collection("users").doc(uid).update(
    {
      savedQues:firebase.firestore.FieldValue.arrayUnion({qid:qid, subject:subject})  
    })
  .then(()=>{
    console.log('book Marked');
    $(`#pyq #${qid} .BookMarkQue`).css('color','blue');
    $(`#pyq #${qid} .BookMarkQue`).attr("state","saved");
  
    $(`#${subject} #${qid}`).clone().appendTo(`#${subject}_save`);
  })

}else if($(e.target).attr("state")=="saved"){

  db.collection("users").doc(uid).update(
    {
      savedQues:firebase.firestore.FieldValue.arrayRemove({qid:qid, subject:subject})
    
     }
  )
  .then(()=>{
    console.log('removed book mark');
    $(`#pyq #${qid} .BookMarkQue`).css('color','black');
    $(`#pyq #${qid} .BookMarkQue`).attr("state","none");
    $(`#${subject}_save #${qid}`).remove();
  })
}
})





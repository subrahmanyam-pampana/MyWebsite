const storageRef = storage.ref();
/*------------------------------------Upload image to storage--------------------------------------------------------------------*/
function uploadFile(imageProp, Imgname, imagePath, file, id) {
  /*-----------------------------Uploading image----------------------------------------------------------------------*/

  var uploadTask = storageRef.child(imagePath).put(file);
  /*------------------------------Showing upload status---------------------------------------------------------------------*/

  uploadTask.on(
    "state_changed",
    (snapshot) => {
      var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      $("#uploadStatus").text("uploaded " + progress + "%");
    },
    /*------------------------------on Error ---------------------------------------------------------------------*/
    (error) => {
      alert("Error:" + error);
    },
    /*----------------------------on completion of upload-------------------------------------------------------------------*/
    () => {
      var imageUrl;
      uploadTask.snapshot.ref.getDownloadURL().then((url) => {
        imageUrl = url;
        console.log(imageUrl);

        var props = {};
        props[imageProp] = imageUrl;
        props[Imgname] = imagePath;

        console.log(props);
        db.collection("questions")
          .doc(id)
          .update(props)
          .then(() => {
            alert("image upload successfully with path: " + imageUrl);
          });
      });
    }
  );
}

/*---------------Browse files------------------------------------------------*/

function browseFiles() {
  var promise = new Promise((resolve, reject) => {
    var input = document.createElement("input");
    input.type = "file";
    var files = "";
    input.click();
    input.onchange = (event) => {
    //   console.log(event.target.files);
      files = event.target.files;
      resolve(files);
      reject();
    };
  });
  return promise;
}

var searchParams = new URLSearchParams(location.search);
var loader = $("#loader");
var userName;
var uid;
var savedQues = [];

auth.onAuthStateChanged((user) => {
  if (user) {
    console.log("login user id: " + user.uid);
    uid = user.uid;
    setupUI(user);

    // real time chat updates
    $("#rightPannel").addClass("showBottomScreen");
    $("#rightPannel .userMsg").remove();

    db.collection("doubts").onSnapshot((snapshot) => {
      let changes = snapshot.docChanges();
      changes.forEach((change) => {
        if (change.type == "added") {
          renderDoubts(change.doc);
        } else if (change.type == "removed") {
          console.log(change.type);
          let queDiv = $("#rightPannel").find(
            "[data-id=" + change.doc.id + "]"
          );
          $(queDiv).remove();
        } else if (change.type == "modified") {
          updateChat(change.doc);
        }
      });
    });

    /*--------------Update Book saved Questions------------------------------------*/

    // db.collection("users")
    //   .where("uid", "==", uid)
    //   .onSnapshot((snapshot) => {
    //     snapshot.docChanges().forEach((change) => {
    //       console.log(change.type);

    //       var doc = change.doc;

    //       //on added or modified
    //       if (doc.exists && doc.data().savedQues) {
    //         if (change.type === "added" || change.type === "modified") {
    //           var questionNum = 1;
    //           doc.data().savedQues.forEach((ele) => {
    //             savedQues.push(ele.qid);
    //             console.log(savedQues);
    //             db.collection("questions")
    //               .doc(ele.qid)
    //               .get()
    //               .then((qdoc) => {
    //                 fnrenderQuetions(qdoc, ele.subject + "_save", questionNum);
    //               });
    //             questionNum++;
    //           });
    //         }
    //       }
    //     });
    //   });

    db.collection("users")
      .doc(uid)
      .get()
      .then((doc) => {
        if (doc.exists && doc.data().savedQues) {

            var questionNum = 1;
            doc.data().savedQues.forEach((ele) => {
              savedQues.push(ele.qid);
              console.log(savedQues);
              db.collection("questions")
                .doc(ele.qid)
                .get()
                .then((qdoc) => {
                  fnrenderQuetions(qdoc, ele.subject + "_save", questionNum);
                });
              questionNum++;
            });
          
        }
      });
      
  } else {
    setupUI();
    var html = "<div class='userMsg'><p>Please login to ASk Doubts</p></div>";
    $("#rightPannel").find(".doubt_div").remove();
    $("#rightPannel").removeClass("showBottomScreen");
    $("#rightPannel").html(html);
    $("#loader").hide();
  }
});

//sign up user
const signUpForm = document.querySelector("#signup-form");

$(signUpForm).submit((e) => {
  e.preventDefault();
  const email = $(signUpForm).find("#signup-email").val();
  const password = $(signUpForm).find("#signup-password").val();
  const userName = $(signUpForm).find("#signup-userName").val();

  auth
    .createUserWithEmailAndPassword(email, password)
    .then((cred) => {
      // Signed in
      var user = cred.user;
      db.collection("users").doc(cred.user.uid).set({
        userName: userName,
      });

      var modal = document.querySelector("#modal-signup");
      M.Modal.getInstance(modal).close();
      signUpForm.reset();
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;

      console.log(errorCode, errorMessage);
    });
});

//logount user
$("#logout").click((e) => {
  e.preventDefault();
  auth.signOut().then(() => {
    $(".sidenav").sidenav();
  });
});

//login user
const loginForm = document.querySelector("#login-form");
$(loginForm).submit((e) => {
  e.preventDefault();
  const email = $("#login-email").val();
  const password = $("#login-password").val();

  auth
    .signInWithEmailAndPassword(email, password)
    .then((cred) => {
      var user = cred.user;
      // console.log('user id: '+cred.user.id);
      // //   console.log(user);
      //   console.log("login successfully");
      var modal = document.querySelector("#modal-login");
      M.Modal.getInstance(modal).close();
      loginForm.reset();
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
      console.log(errorCode, errorMessage);
    });
});

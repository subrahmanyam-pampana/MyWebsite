var searchParams = new URLSearchParams(location.search);
var loader = $("#loader");
var userName ;
auth.onAuthStateChanged((user) => {
  if (user) {
    console.log("logiden user, ", user);
    setupUI(user);
    $(loader).hide();

    if (searchParams.get("filterName")) {
      var filterName = searchParams.get("filterName");
      var filterVal = searchParams.get("filterValue");
      filterQuestions(filterName, filterVal);
      searchParams.delete("filterName");
      searchParams.delete("filterValue");
    } else {
      getdata($("#home"), "all");
    }

    // real time updates
    db.collection("doubts").onSnapshot((snapshot) => {
      let changes = snapshot.docChanges();
      changes.forEach((change) => {
        if (change.type == "added") {
          renderDoubts(change.doc);
        } else if (change.type == "removed") {
          console.log(change.type);
          let queDiv = $("#rightPannel").find(
            "[data-id=" + change.doc.id + "]"
          );
          $(queDiv).remove();
        } else if (change.type == "modified") {
          updateChat(change.doc);
        }
      });
    });
  } else {
    setupUI();
    var html = "<h5>Login view Questions</h5>";
    $("#parentDiv").html(html);
    filterQuestions();
    $("#rightPannel").find(".doubt_div").remove();
    $("#loader").hide();
    // console.log('user logged out');
  }
});

//sign up user
const signUpForm = document.querySelector("#signup-form");

$(signUpForm).submit((e) => {
  e.preventDefault();
  const email = $(signUpForm).find("#signup-email").val();
  const password = $(signUpForm).find("#signup-password").val();
  const userName = $(signUpForm).find("#signup-userName").val();

  auth
    .createUserWithEmailAndPassword(email, password)
    .then((cred) => {
      // Signed in
      var user = cred.user;
      db.collection("users").doc(cred.user.uid).set({
        userName: userName,
      });

      var modal = document.querySelector("#modal-signup");
      M.Modal.getInstance(modal).close();
      signUpForm.reset();
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;

      console.log(errorCode, errorMessage);
    });
});

//logount user
$("#logout").click((e) => {
  e.preventDefault();
  auth.signOut().then(() => {});
});

//login user
const loginForm = document.querySelector("#login-form");
$(loginForm).submit((e) => {
  e.preventDefault();
  const email = $("#login-email").val();
  const password = $("#login-password").val();

  auth
    .signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      var user = userCredential.user;
      //   console.log(user);
      //   console.log("login successfully");
      var modal = document.querySelector("#modal-login");
      M.Modal.getInstance(modal).close();
      loginForm.reset();
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
      console.log(errorCode, errorMessage);
    });
});
